﻿namespace PlannerWebApp.Models
{
    public class Planner
    {
        public int Id { get; set; }
        public string Module { get; set; }
        public string Task { get; set; }
        public string Status { get; set; }
        public string DateDue { get; set; }

        public Planner()
        {
                
        }
    }
}
